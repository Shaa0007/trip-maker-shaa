// script.js

// Update footer year automatically
const yearSpan = document.getElementById("year");
if (yearSpan) {
  yearSpan.textContent = new Date().getFullYear();
}

// Basic testimonial slider (auto-fade)
const testimonials = document.querySelectorAll(".testimonial-slider .testimonial");
let currentTestimonial = 0;

function showTestimonial(index) {
  testimonials.forEach((t, i) => {
    t.style.display = i === index ? "block" : "none";
  });
}

function nextTestimonial() {
  currentTestimonial = (currentTestimonial + 1) % testimonials.length;
  showTestimonial(currentTestimonial);
}

if (testimonials.length > 1) {
  showTestimonial(currentTestimonial);
  setInterval(nextTestimonial, 4000);
}

// Smooth scroll for anchor links
const links = document.querySelectorAll("a[href^='#']");
for (let link of links) {
  link.addEventListener("click", function(e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute("href"));
    if (target) {
      target.scrollIntoView({ behavior: "smooth" });
    }
  });
}

